<h1>Email Verification</h1>

<p>{!!  $body  !!}</p>

